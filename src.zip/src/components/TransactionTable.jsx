import { useEffect, useState } from 'react';
import styled from 'styled-components';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';

const TransactionTable = () => {
    const { user } = useAuth();
    const [transactions, setTransactions] = useState([]);
    const [filterType, setFilterType] = useState('all');
    const [search, setSearch] = useState('');

    useEffect(() => {
        const fetch = async () => {
            try {
                const res = await axios.get(`${import.meta.env.VITE_API_BASE}/api/transactions`, {
                    headers: { Authorization: `Bearer ${user.token}` },
                });
                setTransactions(res.data);
            } catch (err) {
                console.error('Table fetch error:', err.message);
            }
        };
        fetch();
    }, []);

    const filtered = transactions.filter((txn) => {
        const matchType = filterType === 'all' || txn.type === filterType;
        const matchSearch = txn.category.toLowerCase().includes(search.toLowerCase()) || txn.description?.toLowerCase().includes(search.toLowerCase());
        return matchType && matchSearch;
    });

    return (
        <>
            <Wrapper>
                <Top>
                    <h3>Transactions</h3>
                    <Controls>
                        <input
                            type="text"
                            placeholder="Search Cat./Desc."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <select value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                            <option value="all">All</option>
                            <option value="income">Income</option>
                            <option value="expense">Expense</option>
                        </select>
                    </Controls>
                </Top>

                <Table>
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.map((txn) => (
                            <tr key={txn._id}>
                                <td>{txn.type}</td>
                                <td>₹ {txn.amount.toLocaleString()}</td>
                                <td>{txn.category}</td>
                                <td>{txn.description || '-'}</td>
                                <td>{format(new Date(txn.date), 'dd MMM yyyy')}</td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </Wrapper>
        </>
    );
};

export default TransactionTable;

const Wrapper = styled.div`
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    overflow-x: auto;

    @media (width<700px) {
        padding: 0;
    }

    transition: 0.2s ease;
    transition-property: box-shadow;
    &:hover {
        box-shadow: 0 6px 12px rgba(0,0,0,0.5);
    }
`;

const Top = styled.div`
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    align-items: center;

    @media (width<700px) {
        flex-direction: column;
        align-items: flex-start;
        padding: 15px;
    }
`;

const Controls = styled.div`
    display: flex;
    gap: 10px;
    input {
        padding: 6px 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }
    select {
        padding: 6px;
        border-radius: 6px;
    }
`;

const Table = styled.table`
    border: 1px solid #000;
    border-radius: 6px;
    width: 100%;

    thead {
        border: 1px solid #f00;
        background: #333;

        tr {
            th {
                @media (width<700px) {
                    font-size: 10px;
                }
            }
        }
    }

    tbody {
        tr {
            td {
                text-align: center;
                @media (width<700px) {
                    font-size: 10px;
                }
            }
        }
    }
`;

